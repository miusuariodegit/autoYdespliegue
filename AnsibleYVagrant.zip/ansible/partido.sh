#!/bin/bash
rm /vagrant/partido.txt

echo "** INFORMACION DEL PARTIDO UNIR **" >> /vagrant/partido.txt
echo "" >> /vagrant/partido.txt

echo "First Name: $1" >> /vagrant/partido.txt
echo "Last Name: $2" >> /vagrant/partido.txt
echo "City: $3" >> /vagrant/partido.txt
echo "id: $4" >> /vagrant/partido.txt

echo "" >> /vagrant/partido.txt

echo "First Name: $5" >> /vagrant/partido.txt
echo "Last Name: $6" >> /vagrant/partido.txt
echo "City: $7" >> /vagrant/partido.txt
echo "id: $8" >> /vagrant/partido.txt

echo "" >> /vagrant/partido.txt

dia=$(date +%d)
mes=$(date +%m)
anio=$(date +%Y)

if [ $dia -eq 28 ]; then
dia=0
fi

dia=$((dia+1))

nuevodia="$anio-$mes-$dia"
nuevodia=$nuevodia"T10:00:00Z"

echo "Fecha: $nuevodia" >> /vagrant/partido.txt

