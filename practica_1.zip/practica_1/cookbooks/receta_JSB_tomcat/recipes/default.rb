#
# Cookbook:: receta_JSB_tomcat
# Recipe:: default
#
# Copyright:: 2025, The Authors, All Rights Reserved.


# instala jdk
package 'openjdk-11-jdk' do
  action :install
end

# establece JAVA_HOME
execute 'set_java_home' do
  command 'echo "export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64" >> /etc/profile.d/java.sh'
  not_if 'grep JAVA_HOME /etc/profile.d/java.sh'
  only_if {File.exists?('/usr/lib/jvm/java-11-openjdk-amd64')} # Check if the path exists
end

#descarga y descomprime el tomcat en la carpeta tmp
remote_file '/tmp/apache-tomcat-9.0.107.tar.gz' do
  source 'https://downloads.apache.org/tomcat/tomcat-9/v9.0.107/bin/apache-tomcat-9.0.107.tar.gz'
  action :create
end

#crea el directorio de tomcat
directory '/opt/tomcat' do
  recursive true
  action :create
end

#descomprime el tomcat el directorio /opt/tomcat
execute 'extract_tomcat' do
  command 'tar xzf /tmp/apache-tomcat-9.0.107.tar.gz -C /opt/tomcat --strip-components=1'
  not_if { ::File.exist?('/opt/tomcat/bin/startup.sh') }
end

#sudo chmod 777 bin/
#asigna permisos de ejecucion a los archivos .sh de tomcat
execute 'make_tomcat_executable' do
  command 'chmod +x /opt/tomcat/bin/*.sh'
end

#crea el usuario tomcat 
user 'tomcat' do
  system true
  shell '/bin/false'
end


#crea el archivo /etc/systemd/system/tomcat.service para crear el servicio
file '/etc/systemd/system/tomcat.service' do
  content <<-EOF
[Unit]
Description=Apache Tomcat
After=network.target

[Service]
Type=forking

Environment=CATALINA_PID=/opt/tomcat/temp/tomcat.pid
Environment=CATALINA_HOME=/opt/tomcat
Environment=CATALINA_BASE=/opt/tomcat
ExecStart=/opt/tomcat/bin/startup.sh
ExecStop=/opt/tomcat/bin/shutdown.sh
User=root
Group=root
UMask=0007
RestartSec=10
Restart=always

[Install]
WantedBy=multi-user.target
  EOF
  mode '0644'
  notifies :run, 'execute[daemon-reload]', :immediately
end


#recarga los servicios del demonio de ejecucion
execute 'daemon-reload' do
  command 'systemctl daemon-reexec'
  action :nothing
end

#inicia el servicio de tomcat
service 'tomcat' do
  action [:enable, :start]
end


#sudo chmod 777 webapps/

# Copiar el archivo WAR a la carpeta webapps de Tomcat
cookbook_file "/opt/tomcat/webapps/helloworld.war" do
  source 'helloworld.war' 
  owner 'tomcat'
  group 'tomcat'
  mode '0644'
  action :create
end

# Asegurarse de que Tomcat se reinicie y despliegue la aplicación
service 'tomcat' do
  action :restart
end






