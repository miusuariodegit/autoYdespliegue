#
# Cookbook:: ejemplo-iis
# Recipe:: default
#
# Copyright:: 2025, The Authors, All Rights Reserved.

# Instala el rol de servidor web (IIS)
windows_feature 'IIS-WebServerRole' do
  action :install
  all true
end

windows_feature 'IIS-ManagementConsole' do
  action :install
  all true
end

# Crea un archivo HTML en el directorio por defecto de IIS
file 'C:\\inetpub\\wwwroot\\index.html' do
  content '<h1>¡Hola desde Chef en Windows!</h1>'
end

# Asegura que el servicio de IIS esté activo
service 'W3SVC' do
  action [:enable, :start]
end
