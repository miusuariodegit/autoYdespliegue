# InSpec test for recipe ejemplo-iis::default

# The InSpec reference, with examples and extensive documentation, can be
# found at https://www.inspec.io/docs/reference/resources/

# Verifica que IIS-WebServerRole esté habilitado usando DISM
describe powershell('dism /online /Get-FeatureInfo /FeatureName:IIS-WebServerRole') do
  its('stdout') { should match /State : Enabled/ }
end

# Verifica que IIS-ManagementConsole esté habilitado usando DISM
describe powershell('dism /online /Get-FeatureInfo /FeatureName:IIS-ManagementConsole') do
  its('stdout') { should match /State : Enabled/ }
end

# Verifica que el servicio W3SVC esté activo
describe service('W3SVC') do
  it { should be_installed }
  it { should be_enabled }
  it { should be_running }
end

# Verifica que el archivo HTML exista y contenga el mensaje esperado
describe file('C:\\inetpub\\wwwroot\\index.html') do
  it { should exist }
  its('content') { should match /Hola desde Chef en Windows/ }
end
