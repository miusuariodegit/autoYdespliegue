# ejemplo-iis

Este cookbook automatiza la configuración de un servidor web IIS en entornos Windows utilizando 
Chef Workstation.

## Descripción

La receta `default.rb` instala las características necesarias de IIS, genera un archivo HTML 
personalizado en el directorio web y asegura que el servicio esté activo. 
Está diseñado para simplificar el despliegue de servidores básicos de desarrollo o pruebas.

## Requisitos

- Chef Workstation 15 o superior
- Sistema operativo: Windows 10 versión 22H2 o posterior
- Permisos de administrador
- Conexión a internet para instalación de componentes

## 📂 Estructura del cookbook

```plaintext
ejemplo-iis/
├── recipes/
│   └── default.rb
├── metadata.rb
├── README.md


