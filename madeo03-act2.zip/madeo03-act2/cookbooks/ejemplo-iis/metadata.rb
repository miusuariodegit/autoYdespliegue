name 'ejemplo-apache'
maintainer 'Daniel Antonio Nieblas Fuentes'
maintainer_email 'danielantonio.nieblasFD0@comunidadunir.net'
license 'All Rights Reserved'
description 'Instala el servicio de IIS y configura una página HTML'
long_description 'Instala el servicio de IIS y configura una página HTML'
version '0.1.0'
chef_version '>= 14.0'

