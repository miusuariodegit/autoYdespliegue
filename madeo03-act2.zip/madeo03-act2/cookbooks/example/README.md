# Example

An example cookbook

## Requirements

### Platforms:

_No platforms defined_

### Cookbooks:

_No dependencies defined_

## Attributes

- `node['example']['name']` - Defaults to `Sam Doe`.

## Recipes

- example::default

## License and Maintainer

Maintainer:: (<>)

License:: All rights reserved
